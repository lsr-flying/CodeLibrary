    
//数据源

var dContainerVal = {
						"one":{"cmp":[8,1.6,1481,0.31,0.41,93,25],"std":[11,6,2932,0.4,0.5,93,16]},
						"two":{"cmp":[3,0.7,1206,0.59,0.53,0,9,3],"std":[13,6,2779,0.58,0.22,0,20,13]},
						"three":{"cmp":[8,1.6,1481,0.31,0.41,93,25,8],"std":[11,6,2932,0.4,0.5,93,16,11]},
						"four":{"cmp":[8,1.6,1481,0.31,0.41,93,25,8],"std":[11,6,2932,0.4,0.5,93,16,11]}
					};

var pContainerVal = {
						"one":{"cmp":[15,7,1481,0.31,0.41,100,25],"std":[11,6,2932,0.4,0.5,93,16]},
						"two":{"cmp":[3,0.7,1206,0.59,0.53,0,9,3],"std":[13,6,2779,0.58,0.22,0,20,13]},
						"three":{"cmp":[60,1.6,1481,0.31,0.41,131,25,8],"std":[11,6,2932,0.4,0.5,93,16,11]},
						"four":{"cmp":[8,1.6,1481,0.31,0.41,93,25,8],"std":[11,6,2932,0.4,0.5,93,16,11]}
					};

var qContainerVal = {
						"one":{"cmp":[8,1.6,1481,0.31,0.41,93,25],"std":[11,6,2932,0.4,0.5,93,16]},
						"two":{"cmp":[3,0.7,1206,0.59,0.53,0,91,3],"std":[13,6,2779,0.58,0.22,0,20,13]},
						"three":{"cmp":[18,1.6,3481,0.31,0.41,93,25,8],"std":[11,6,2932,0.4,0.5,93,16,11]},
						"four":{"cmp":[14,1.6,3481,0.31,0.41,94,25,8],"std":[11,6,2932,0.4,0.5,93,16,11]}
					};

String.prototype.format=function()  
{  
  if(arguments.length==0) return this;  
  for(var s=this, i=0; i<arguments.length; i++)  
    s=s.replace(new RegExp("\\{"+i+"\\}","g"), arguments[i]);  
  return s;  
};  

function checkColor(cmpBrick,stdBrick,ratio){
	var cmpInt = parseFloat($(cmpBrick).html());
	var stdInt = parseFloat($(stdBrick).html());
	var rationInt = parseFloat(ratio);

	if( cmpInt <= stdInt ){
		$(cmpBrick).css("background","lightgreen");
	}
	else if( cmpInt <= stdInt*ratio){
		$(cmpBrick).css("background","yellow");
	}
	else{
		$(cmpBrick).css("background","red");
	}
}

//三角砖选择器
var brickSelector = ".{0} .row{1}{2} .col{3}";

function populate(container,val){

	//第一层
	populateRow(container,"1",val["one"]);
	populateRow(container,"2",val["two"]);
	populateRow(container,"3",val["three"]);
	populateRow(container,"4",val["four"]);
}

function populateRow(container,rowNum,rowVal){
	var std = rowVal["std"];
	var cmp = rowVal["cmp"];

	for(var i=0;i<7;i++){
		var upSlt = brickSelector.format(container,rowNum,"u",i+1);
		var dwSlt = brickSelector.format(container,rowNum,"d",i+1);
		$(dwSlt).html(cmp[i]);
		$(upSlt).html(std[i]);
		checkColor(dwSlt,upSlt,"1.5");
	}
}

$(document).ready(function(){

	//渲染模板
	$( "#pyramidModel" ).tmpl({"container":"dContainer","name":"Defect Cost"})
		.appendTo( "#dContainer" );
	$( "#pyramidModel" ).tmpl({"container":"pContainer","name":"PPM"})
		.appendTo( "#pContainer" );	
	$( "#pyramidModel" ).tmpl({"container":"qTContainer","name":"Process Q"})
		.appendTo( "#qTContainer" );	

	//填充数据
	populate("dContainer",dContainerVal);
	populate("pContainer",pContainerVal);
	populate("qTContainer",qContainerVal);

	$(".flexslider").flexslider(); 
});



