var wholeStatus = {"1":"1","2":"2","3":"1","4":"1","5":"1","6":"1","7":"1","8":"1","9":"1","10":"1","11":"2","12":"2","13":"2","14":"2","15":"3","16":"3"
,"17":"3","18":"1","19":"1","20":"1","21":"1","22":"1","23":"1","24":"1","25":"1","26":"1","27":"1","28":"","29":"1","30":"3","31":"3"};

var erStatus = {"1":"2","2":"1","3":"1","4":"1","5":"3","6":"1","7":"1","8":"1","9":"2","10":"1","11":"2","12":"1","13":"1","14":"1","15":"1","16":"1"
,"17":"3","18":"1","19":"1","20":"1","21":"1","22":"1","23":"1","24":"1","25":"1","26":"1","27":"1","28":"","29":"1","30":"1","31":"2"};

var ecStatus = {"1":"3","2":"1","3":"2","4":"2","5":"1","6":"2","7":"1","8":"1","9":"2","10":"1","11":"2","12":"1","13":"1","14":"1","15":"1","16":"1"
,"17":"3","18":"1","19":"1","20":"1","21":"1","22":"1","23":"1","24":"1","25":"1","26":"1","27":"1","28":"","29":"1"};

var colorMatch = {"1":"green","2":"yellow","3":"red"};

function setStatus(qType,monthStatus){
	for(var dayStat in monthStatus){
		var color = colorMatch[monthStatus[dayStat]];
		var selector = "."+qType+" .item"+dayStat;
		$(selector).css("background",color);
	}
}


<!-- 初始化 Foundation JS -->
$(document).ready(function() {
    $(document).foundation();

    var month1 = {qType:"er",thirtyOne:1,thirty:0,twentyNine:0,twentyEight:0};
    var month2 = {qType:"ec","thirtyone":0,"thirty":0,"twentyNine":1,"twentyEight":0};
	var month3 = {qType:"whole","thirtyone":0,"thirty":1,"twentyNine":0,"twentyEight":0};

$( "#movieTemplate" ).tmpl( month1 )
.appendTo( "#erQContainer" );
setStatus("er",erStatus);

$( "#movieTemplate" ).tmpl( month2 )
.appendTo( "#ecQContainer" );
setStatus("ec",ecStatus);

$( "#movieTemplate" ).tmpl( month3 )
.appendTo( "#wholeQContainer" );
setStatus("whole",wholeStatus);

})



$(function() { 
    $(".flexslider").flexslider(); 
});

	$("#btnThirtyOne").click(function(){
		$(".qContainer").css("display","none");
		$(".thirtyone").css("display","block");
	});

	$("#btnThirty").click(function(){
		$(".qContainer").css("display","none");
		$(".thirty").css("display","block");
	});

	$("#btnTwentyNine").click(function(){
		$(".qContainer").css("display","none");
		$(".twenty-nine").css("display","block");
	});

	$("#btnTwentyEight").click(function(){
		$(".qContainer").css("display","none");
		$(".twenty-eight").css("display","block");
	});


	$("#btnWhole").click(function(){
		$(".qContainer .item").css("background","");
		$(".qContainer .item1").css("background","green");
       $(".qContainer .item5").css("background","red");
	});

	$("#btnER").click(function(){
		$(".qContainer .item").css("background","");
		$(".item3").css("background","yellow");
       $(".item4").css("background","red");
	});

	$("#btnEC").on("click",function(){
			$(".qContainer .item").css("background","");
			$(".qContainer .item6").css("background","yellow");
       		$(".qContainer .item7").css("background","red");
       		$(".qContainer .item8").css("background","red");
	});
